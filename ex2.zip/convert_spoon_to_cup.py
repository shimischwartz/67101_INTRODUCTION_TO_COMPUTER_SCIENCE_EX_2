#################################################################
#FILE:convert_spoon_to_cup.py
#WRITER:shimon_schwartz , shimioschwartz , 201572807
#EXERCIS:iA code that converts a number to a
#number 16 times smaller
#################################################################
def convert_spoon_to_cup(spoons):
    """a function that receives a number and
    returns a 16 times smaller amount"""
    return spoons/16